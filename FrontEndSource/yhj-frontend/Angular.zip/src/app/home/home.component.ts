import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  login() {
    const clientId = '17maovn490jgjo4sahig56bs9b';
    const domain = 'us-east-2qhnriu1dn.auth.us-east-2.amazoncognito.com';
    const redirectUri = encodeURIComponent(
      'http://localhost:4200/angular/auth-callback'
    );
    const responseType = 'code';
    const scope = 'openid email';

    const loginUrl = `https://${domain}/login?client_id=${clientId}&response_type=${responseType}&scope=${scope}&redirect_uri=${redirectUri}`;

    window.location.href = loginUrl;
  }
}
